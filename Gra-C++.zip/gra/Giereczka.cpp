#include <iostream>
#include <map>
#include <conio.h>
#include <vector>
#include <cstdlib>
using namespace std;



class Potwory {
private:
    int x;
    int y;
    int HP;
    int DMG;
    string symbol;
    string nazwa;
public:
    Potwory(string nazwa){
        this->nazwa= nazwa;

        if(nazwa == "ork"){
            x = 4;
            y = 4;
            HP = 350;
            DMG = 30;
            symbol = "O ";
        }else if(symbol == "smok"){
            x = 20;
            y = 20;
            HP = 150;
            DMG = 150;
            symbol = "S ";
        }

    };
    int getHP() const{
        return HP;
    };
    int getDMG() const{
        return DMG;
    };
    int getX() const{
        return x;
    };
    int getY() const{
        return y;
    };

    void setX(int nowy){
        x = nowy;
    };
    void setY(int nowy1) {
         y = nowy1;
    };
    string getSymbol() const {
        return symbol;
    };
    string getNazwa() const {
        return nazwa;
    };
    void zmniejszHP(int damage) { 
        HP -= damage; 
    };



};



class Postac {

private:
    int x;
    int y;
    int HP;
    int DMG;
    string symbol;
    string typ;
public:

    Postac(int x, int y) {
        this->x=x;
        this->y=y;
        
        cout << "Postacie do wyboru: " << endl;
        cout << "1. Wojownik" << endl;
        cout << "2. Mag" << endl;
        int wybor;
        cin >> wybor; 

        switch (wybor) {
            case 1:
                HP = 200;
                DMG = 50;
                symbol = "W ";
                
                break;
            case 2:
                HP = 100;
                DMG = 100;
                symbol = "M ";
                break;
            default:
                cout << "Nieprawidłowy wybór! Ustawiono Wojownika." << endl;
                HP = 200;
                DMG = 50;
                symbol = "W ";
        }
    }

    int getHP() const{
        return HP;
    };
    int getDMG() const{
        return DMG;
    };
    int getX() const{
        return x;
    };
    int getY() const{
        return y;
    };
    void setX(int nowy){
        x = nowy;
    };
    void setY(int nowy1) {
         y = nowy1;
    };
    string getSymbol() const {
        return symbol;
    };
    string getTyp() const { 
        return typ; 
    };
    void zmniejszHP(int damage){ 
        HP -= damage; 
    };
};

class Mapa {
private:
    int wysokosc = 27; 
    int szerokosc = 27;
    map<pair<int, int>, string> testMap;
    vector<Potwory> potwory;

public:
    Mapa(int wysokosc, int szerokosc){
        this->wysokosc=wysokosc;
        this->szerokosc=szerokosc;
    }

    void Stworz(){
        int i;
        int j;

        for(i = 0;i<szerokosc;i++){
            for(j = 0;j<wysokosc;j++){
                if(i==0 || i==szerokosc-1){
                        testMap[make_pair(i,j)] = "- ";
                    }else if(j==0 || j==wysokosc-1){
                        testMap[make_pair(i,j)] = "| ";
                    }
                    else{
                        testMap[make_pair(i,j)] = "  ";
                }
            }
        }
    }

    void Wyswietl(){
        int i;
        int j;
        for(i = 0;i<szerokosc;i++){
            for(j = 0;j<wysokosc;j++){
                cout << testMap[make_pair(i,j)];
            }
            cout << endl;
        }
    }

    void Ustaw(Postac &bohater){
        testMap[make_pair(bohater.getX(),bohater.getY())] = bohater.getSymbol();
        
    }

    int odleglosc(int x1, int y1, int x2, int y2) {
        return abs(x1 - x2) + abs(y1 - y2);
    }

    void UstawPotwora(Potwory &potwor){
        potwory.push_back(potwor);
        testMap[make_pair(potwor.getX(),potwor.getY())] = potwor.getSymbol();
    }

    bool SprawdzCzyPotworNaPozycji(int x, int y) {
        for (auto &potwor : potwory) {
            if (potwor.getX() == x && potwor.getY() == y) {
                return true; 
            }
        }
        return false; 
    };

    void WyswietlStatystyki(Postac &bohater) {
    cout << "\n===== STATYSTYKI =====" << endl;
    cout << "Bohater (" << bohater.getSymbol() << "): HP = " << bohater.getHP() << ", DMG = " << bohater.getDMG() << endl;

    for (const auto& potwor : potwory) {
        cout << potwor.getNazwa() << " (" << potwor.getSymbol() << "): HP = " 
             << potwor.getHP() << ", DMG = " << potwor.getDMG() << endl;
    }
}

    void Atak(Postac &atakujacy, Potwory &potwor) {
        int zasieg = (atakujacy.getTyp() == "Wojownik") ? 1 : 3;

        int odlegloscAtakujacego = odleglosc(atakujacy.getX(), atakujacy.getY(), potwor.getX(), potwor.getY());

        if (odlegloscAtakujacego <= zasieg) {
            cout << atakujacy.getSymbol() << " atakuje " << potwor.getSymbol() << "!" << endl;
            potwor.zmniejszHP(atakujacy.getDMG());
            cout << potwor.getNazwa() << " traci " << atakujacy.getDMG() << " punktow zdrowia!" << endl;

            if (potwor.getHP() <= 0) {
                cout << potwor.getNazwa() << " został pokonany!" << endl;
                testMap[make_pair(potwor.getX(), potwor.getY())] = "  ";
            }
        } else {
            cout << atakujacy.getTyp() << " nie może zaatakowac " << potwor.getNazwa() << " z tej odległosci!" << endl;
        }
    WyswietlStatystyki(atakujacy);
    }

    void Ruch(char w,Postac &bohater){
        testMap[make_pair(bohater.getX(),bohater.getY())] = "  ";

        int nowyX = bohater.getX();
        int nowyY = bohater.getY();

        switch(w){
            case 'w':
                nowyX--;
                break;  
            case 'a':
                nowyY--;
                break;
            case 's':
                nowyX++;
                break;
            case 'd':
                nowyY++;
                break;
            case 'q':
                return;
            default:
                cout << "Nieprawidlowy klawisz!" <<endl;
                return;
            
        }

        if(nowyX >= 1 && nowyX < szerokosc - 1 && nowyY >= 1 && nowyY < wysokosc - 1){
            bohater.setX(nowyX);
            bohater.setY(nowyY);
            testMap[make_pair(nowyX,nowyY)] = bohater.getSymbol();
        }if (SprawdzCzyPotworNaPozycji(nowyX, nowyY)) {
                cout << "Nie mozesz wejsc na pozycje, na ktorej jest potwor!" << endl;
                testMap[make_pair(bohater.getX(), bohater.getY())] = bohater.getSymbol(); 
                return;
            }
        else{
            testMap[make_pair(bohater.getX(), bohater.getY())] = bohater.getSymbol();
        }

        system("cls");
        Wyswietl();
        WyswietlStatystyki(bohater);
        
    };
};

int main(){
    char ruch;
    Mapa mapa(27,27);
    mapa.Stworz();
    Potwory Ork("ork");
    Potwory Smok("smok");
    Postac bohater(13,13);
    mapa.UstawPotwora(Ork);
    mapa.Ustaw(bohater);
    mapa.Wyswietl();
    cout<<"Podaj kierunek(w/a/s/d) lub 'q' aby wyjsc: "<<endl;
    cout<<"Prosze zapoznaj sie z instrukcja"<<endl;
    while(true){
        
        while(true){
           if(_kbhit()){
                ruch = _getch();
                break;
           };
          
        };
        if(ruch=='q')break;      
        if (ruch == 't') {
            mapa.Atak(bohater, Ork);  
        } else {
            mapa.Ruch(ruch, bohater);
        };

    };
  

    getch();
    return 0;
}